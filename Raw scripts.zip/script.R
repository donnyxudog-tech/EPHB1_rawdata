setwd('z:/users/PRAD_APOPTOSIS')
if (T) {
  dir.create("scripts")
  dir.create("results")
  dir.create("files")
  dir.create("figures")
  dir.create("origin_datas/GEO",recursive = T)
  dir.create("origin_datas/TCGA")
}

library(stringr)
library(tidydr)
library(openxlsx)
library(data.table)
library(reshape2)
library(dplyr)
library(tidyr)
library(tidyverse)
library(clusterProfiler)
library(pheatmap)
library(ComplexHeatmap)
library(GSVA)
library(GSEABase)
library(fgsea)
library(corrplot)
library(colorspace)
library(survival)
library(survminer)
library(maftools)
library(vegan)
library(forcats)
library(ggpubr)
library(ggsci)
library(ggplot2)
library(rstatix)
library(ggcor)
library(ggstance)
options(stringsAsFactors = F)
source('base_function.R')
#TCGA#########
# #临床数据
tcga.cli1<-read.delim('origin_datas/TCGA/Merge_PRAD_clinical.txt',sep='\t',header = T)
colnames(tcga.cli1)[1:30]
tcga.cli1=data.frame(Samples=paste0(tcga.cli1$A0_Samples,'-01'),
                    Age=tcga.cli1$A17_Age,
                    Gender=tcga.cli1$A18_Sex,
                    T.stage=tcga.cli1$A3_T,
                    N.stage=tcga.cli1$A4_N,
                    M.stage=tcga.cli1$A5_M,
                    Gleason.score=tcga.cli1$stage_event.gleason_grading.gleason_score
                    #new_event=tcga.cli1$A8_New_Event,
                    #new_event_time=tcga.cli1$A8_New_Event_Time
					)
 
table(tcga.cli1$T.stage)
tcga.cli1$T.stage <- gsub('[abc]', '', tcga.cli1$T.stage)
tcga.cli1$T.stage[tcga.cli1$T.stage=='']<-NA

table(tcga.cli1$N.stage)
tcga.cli1$N.stage[tcga.cli1$N.stage=='']<-NA

table(tcga.cli1$M.stage)
tcga.cli1$M.stage <- gsub('[abc]', '', tcga.cli1$M.stage)
tcga.cli1$M.stage[tcga.cli1$M.stage=='']<-NA
tcga.cli1=crbind2DataFrame(tcga.cli1)



####生存信息
tcga.pancancer.cli=read.xlsx('TCGA_pancancer_cli_PMID_29625055.xlsx')
head(tcga.pancancer.cli)
tcga.time.cli=tcga.pancancer.cli[which(tcga.pancancer.cli$type=='PRAD'),]
head(tcga.time.cli)
tcga.time.cli=data.frame(Samples=paste0(tcga.time.cli$bcr_patient_barcode,'-01'),
                         tcga.time.cli[,c('OS','OS.time','DSS','DSS.time','DFI','DFI.time','PFI','PFI.time')])


tcga.cli=merge(tcga.time.cli,tcga.cli1,by='Samples')
rownames(tcga.cli)=tcga.cli$Samples
fivenum(tcga.cli$Age)
tcga.cli$Age1=ifelse(tcga.cli$Age>61,'>61','<=61')
dim(tcga.cli)
tcga.cli=crbind2DataFrame(tcga.cli)
head(tcga.cli)


#mRNA表达谱
tcga.data=read.delim('origin_datas/TCGA/Merge_TCGA-PRAD_TPM.txt',row.names = 1,check.names = F)
tcga.data[1:5,1:5]
dim(tcga.data)


table(substr(colnames(tcga.data),14,15))
sample_T=colnames(tcga.data)[which(as.numeric(substr(colnames(tcga.data),14,15))==1)]#肿瘤样本
sample_T=intersect(tcga.cli$Samples,sample_T)
sample_N=colnames(tcga.data)[which(as.numeric(substr(colnames(tcga.data),14,15))==11)]#正常样本
tcga_type=data.frame(Samples=c(sample_T,sample_N),Type=rep(c('Tumor','Normal'),c(length(sample_T),length(sample_N))))
rownames(tcga_type)=tcga_type$Samples
table(tcga_type$Type)
# Normal  Tumor 
# 52    495 

###mRNA表达谱
genecode=read.delim('public/GeneTag.genecode.v32.txt',sep='\t',header = T)
table(genecode$TYPE)
mrna_genecode=genecode[which(genecode$TYPE=='protein_coding'),]
head(mrna_genecode)

tcga.data=tcga.data[intersect(rownames(tcga.data),mrna_genecode$SYMBOL),c(sample_T,sample_N)]
tcga.data=log2(tcga.data+1)
range(tcga.data)
dim(tcga.data)

tcga.exp=tcga.data[,sample_T]
range(tcga.exp)
tcga.cli=tcga.cli[sample_T,]
dim(tcga.exp);dim(tcga.cli)
## 495 例肿瘤样本



#MSKCC##############
####临床特征
mskcc.patient=read.delim('origin_datas/prad_mskcc/data_clinical_patient.txt',skip = 4)
mskcc.sample=read.delim('origin_datas/prad_mskcc/data_clinical_sample.txt',skip = 4)
mskcc.cli=merge(mskcc.patient,mskcc.sample,by='PATIENT_ID')
table(mskcc.cli$SAMPLE_CLASS,mskcc.cli$SAMPLE_TYPE)
mskcc.cli=mskcc.cli[mskcc.cli$SAMPLE_CLASS=='Tumor' & mskcc.cli$SAMPLE_TYPE=='Primary',]
mskcc.cli=data.frame(Samples=mskcc.cli$PATIENT_ID,DFS=str_split_fixed(mskcc.cli$DFS_STATUS,':',2)[,1],
                     DFS.time=mskcc.cli$DFS_MONTHS,
                     Type=mskcc.cli$SAMPLE_TYPE,GLEASON_SCORE=mskcc.cli$GLEASON_SCORE)
rownames(mskcc.cli)=mskcc.cli$Samples
head(mskcc.cli)
dim(mskcc.cli)


#####表达矩阵
mskcc.data=read.delim('origin_datas/prad_mskcc/data_mrna_agilent_microarray.txt',check.names = F)
mskcc.data[1:5,1:5]
dim(mskcc.data)

library(clusterProfiler)
library(org.Hs.eg.db)
#ENSEMBL
keytypes(org.Hs.eg.db)
gene.anno <- bitr(mskcc.data$Entrez_Gene_Id, fromType = "ENTREZID", #fromType是指你的数据ID类型是属于哪一类的
                toType = 'SYMBOL', #toType是指你要转换成哪种ID类型，可以写多种，也可以只写一种
                OrgDb = org.Hs.eg.db)#Orgdb是指对应的注释包是哪个
head(gene.anno)
dim(gene.anno)

mskcc.exp=merge(gene.anno,mskcc.data,by.x='ENTREZID',by.y='Entrez_Gene_Id')
mskcc.exp[1:5,1:5]
mskcc.exp=mskcc.exp[!duplicated(mskcc.exp$SYMBOL),]
rownames(mskcc.exp)=mskcc.exp$SYMBOL
mskcc.exp=mskcc.exp[,-c(1,2)]
mskcc.exp[1:5,1:5]
range(mskcc.exp)
dim(mskcc.exp)

mskcc.sample.T=intersect(colnames(mskcc.exp),mskcc.cli$Samples)
mskcc.exp=mskcc.exp[,mskcc.sample.T]
mskcc.cli=mskcc.cli[mskcc.sample.T,]
mskcc.cli=crbind2DataFrame(mskcc.cli)
dim(mskcc.exp);dim(mskcc.cli)
#131样本






 
#01.WGCNA##########################
dir.create('results/01.WGCNA')
# ####评分计算
load("results/tcga.hall.ssGSEA.RData")
tcga.cli.merge=cbind.data.frame(score=tcga.hall.ssGSEA['HALLMARK_APOPTOSIS',tcga.cli$Samples],tcga.cli)

tcga.cli.merge2=cbind.data.frame(score=tcga.hall.ssGSEA['HALLMARK_APOPTOSIS',tcga_type$Samples],tcga_type)
head(tcga.cli.merge2)
fig1a=tcga.cli.merge2 %>% 
  ggplot(aes(x=Type, y=score,fill=Type)) +
  geom_boxplot()+
  scale_fill_manual(values = pal_futurama()(9)[7:8])+   #箱线图填充颜色
  ggpubr::stat_compare_means(aes(group=Type), label = "p.format", method = 't.test')+
  labs(x="", y = "HALLMARK APOPTOSIS score", fill = "Type") +theme_bw()+
  theme(legend.position = "top",text = element_text(family = 'Times',color = "black",size = 15,face = 'bold')) 
fig1a
ggsave('results/01.WGCNA/fig1a.pdf',fig1a,height = 4.5,width = 3.5)


# cluster gene
library(WGCNA)

allowWGCNAThreads(nThreads = 36)#允许R语言程序最大线程运行
enableWGCNAThreads(nThreads = 36)# 打开多线程


tpm_T2=(2^tcga.exp-1)
tpm_T2=tpm_T2[which(apply(tpm_T2,1,sd)>0),]
tpm_T2=t(tpm_T2)
dim(tpm_T2)
range(tpm_T2)

pdf('results/01.WGCNA/1.pdf',width = 8,height = 8)
tpm_T2.power=wgcna_get_power(tpm_T2)
dev.off()


tpm_T2.power$cutPower
tpm_T2.module=WGCNA_getModule(tpm_T2,
                                 power = tpm_T2.power$cutPower,
                                 deepSplit=2,
                                 mergeCutHeight=0.25,
                                 minModuleSize=30)

table(tpm_T2.module$Modules[,2])
length(table(tpm_T2.module$Modules[,2]))

pdf('results/01.WGCNA/2.pdf',height = 4.5,width = 6)
plotDendroAndColors(tpm_T2.module$Tree, tpm_T2.module$Modules,
                    c("Dynamic Module",'Merged Module'),
                    dendroLabels = FALSE, hang = 0.03,
                    addGuide = TRUE, guideHang = 0.05)
dev.off()
# 
#writeMatrix(tpm_T2.module$Modules,outpath = 'results/01.WGCNA/tcga.wgcna.module.genes.txt')
pdf('results/01.WGCNA/3.pdf',height = 6,width = 6)
barplot_point(labels = names(table(tpm_T2.module$Modules[,2]))
                 ,values = as.numeric(table(tpm_T2.module$Modules[,2]))
                 ,point_sizes = 2
                 ,point_cols = names(table(tpm_T2.module$Modules[,2]))
                 ,xlab = 'Number of Genes',legend.pos = NULL)
dev.off()

#### 模块特征向量聚类
# Calculate eigengenes
MEs = tpm_T2.module$MEs
# Calculate dissimilarity of module eigengenes
MEDiss = 1-cor(MEs);
# Cluster module eigengenes
METree = hclust(as.dist(MEDiss), method = "average");
# Plot the result
pdf('results/01.WGCNA/4.pdf',height = 6,width = 12,onefile = T)
plot(METree, main = "Clustering of module eigengenes",xlab = "", sub = "")
dev.off()

##choose 模块特征向量与临床信息的关系###########

tcga.cli.merge=cbind.data.frame(score=tcga.hall.ssGSEA['HALLMARK_APOPTOSIS',tcga.cli$Samples],
                                tcga.cli)

head(tcga.cli.merge)
colnames(tcga.cli.merge)
tcga_cli_use.part=tcga.cli.merge[,c(19,13:16,1)]
str(tcga_cli_use.part)

tcga_cli_use.part=sapply(tcga_cli_use.part, function(x)as.numeric(as.factor(x)))
spms=tcga_cli_use.part

MEs_col<-tpm_T2.module$MEs
dim(MEs_col)

modTraitCor = cor(MEs_col[,rownames(MEDiss)[METree$order]], spms,use = 'pairwise.complete.obs')
modTraitP = corPvalueStudent(modTraitCor, dim(spms)[1])

textMatrix = paste(signif(modTraitCor, 2), " (", format(modTraitP,scientific =TRUE,digits = 3), ")", sep = "")
dim(textMatrix) = dim(modTraitCor)
dim(textMatrix)

rownames(modTraitCor)=gsub("ME","",rownames(modTraitCor))
rownames(textMatrix)=gsub("ME","",rownames(textMatrix))
colnames(modTraitCor)



pdf('results/01.WGCNA/fig1c.pdf',width =3,height = 12)
labeledHeatmap(Matrix = data.frame(modTraitCor[,6,drop=F]),
               xLabels = colnames(modTraitCor[,6,drop=F]),
               yLabels = rownames(modTraitCor[,6,drop=F]),
               cex.lab = 1,
               ySymbols = colnames(t(modTraitCor[,6,drop=F])), colorLabels = FALSE,
               colors = blueWhiteRed(50),
               textMatrix = data.frame(textMatrix[,6]),
               setStdMargins = FALSE,xLabelsAngle = 0,
               cex.text = 0.8, zlim = c(-1,1),
               main = paste("Module-trait relationships"))
dev.off()

#基因的模块成员度（module membership）计算
#即各基因表达值与相应模块特征基因的相关性，其衡量了基因在全局网络中的位置
## Notes: signedKME函数的列名是根据输入数据的列名称从第3个字母开始截取，所以如果前面的模块
## 的名称前面的ME如果已经去除，记得在前面加上两个字母
geneModuleMembership <- signedKME(tpm_T2
                                  , data.frame(tpm_T2.module$MEs)
                                  , outputColumnName = "")
head(geneModuleMembership)
MMPvalue <- as.data.frame(corPvalueStudent(as.matrix(geneModuleMembership)
                                           , nrow(tpm_T2.module$MEs)))
#各基因表达值与临床表型的相关性分析
geneTraitSignificance <- as.data.frame(cor(tpm_T2
                                           , spms
                                           , use = 'pairwise.complete.obs'))

GSPvalue <- as.data.frame(corPvalueStudent(as.matrix(geneTraitSignificance)
                                           , nrow(spms)))

modNames<-colnames(geneModuleMembership)
modNames


module = "red"
column = match(module, modNames)
column
moduleGenes <- (tpm_T2.module$Modules[,'mergedColors']==module)
wgcna.gene=names(which(moduleGenes))
length(wgcna.gene)
#1274

write.csv(wgcna.gene,'results/01.WGCNA/WGCNA.redModule.genes.csv',row.names = F)

# 
pdf('results/01.WGCNA/fig1d.pdf',height = 5,width = 5)
verboseScatterplot(abs(geneModuleMembership[moduleGenes, column]),
                   abs(geneTraitSignificance[moduleGenes, 'score']),
                   xlab = paste("Module Membership in", module, "module"),
                   ylab = "Gene significance for APOPTOSIS score",
                   main = paste("Module membership vs. gene significance\n"),
                   cex.main = 1.2, cex.lab = 1.2, cex.axis = 1.2
                   , col = module,lwd=2)
dev.off()


##red模块基因富集分析########
enrich_res=my_clusterProfiler(genes =wgcna.gene)

write.xlsx(list(KEGG=enrich_res$KEGG@result,GO_BP=enrich_res$GO_BP@result),
           file = 'results/01.WGCNA/WGCNA_enrichment.xlsx',overwrite = T)


fig1e=enrichplot::dotplot(enrich_res$KEGG)+ggtitle('KEGG')+
  theme(text=element_text(family = 'Times'))+scale_y_discrete(labels=function(y)str_wrap(y,width = 25))
fig1f=enrichplot::dotplot(enrich_res$GO_BP)+ggtitle('Biological Process')+
  theme(text=element_text(family = 'Times'))+scale_y_discrete(labels=function(y)str_wrap(y,width = 25))
dev.off()

fig1ef=merge_plot(fig1e,fig1f,nrow = 2,ncol=1,labels = c('E','F'))
ggsave('results/01.WGCNA/Fig1ef.pdf',fig1ef,height = 8,width = 6)


#02.差异基因筛选########
dir.create('results/02.NvsT_DEGs')
tcga.limma=limma_DEG(exp = tcga.data[,tcga_type$Samples],group = tcga_type$Type,
                        ulab = 'Tumor',dlab = 'Normal')
tcga.limma$Summary
tcga.DEGs=tcga.limma$DEG[tcga.limma$DEG$adj.P.Val<0.05 & abs(tcga.limma$DEG$logFC)>log2(2),]
write.csv(tcga.DEGs,'results/02.NvsT_DEGs/tcga.DEGs.csv')
fig2a=my_volcano(dat = tcga.limma,p_cutoff = 0.05,fc_cutoff = log2(2),col = c('orange','skyblue','grey'),
                 leg.pos = 'top')
fig2a

tcga.DEGs.filter=tcga.DEGs
tcga.DEGs.filter$type=ifelse(tcga.DEGs.filter$logFC>0,'up','down')
tcga.DEGs.filter <- tcga.DEGs.filter %>%
  mutate(gene = rownames(tcga.DEGs.filter))  %>%
  group_by(type) %>% slice_max(n =50, order_by = abs(logFC)) %>%  arrange(logFC)
head(tcga.DEGs.filter)

cli_anno=tcga_type[,'Type',drop=F]
fig2b=pheatmap(tcga.data[tcga.DEGs.filter$gene,rownames(cli_anno)],
               scale = 'row',name = 'Expression',  main="TOP50 DEGs in TCGA", # 设置图形标题
               color =  circlize::colorRamp2(c(-3, 0, 3), c('#009B9F', "white", '#C75DAA')),
               annotation_col = cli_anno,
               annotation_colors = list(Type=c(Tumor='#FF95A8FF',Normal='#84D7E1FF')),
               cluster_cols = F, # 去掉横向、纵向聚类
               cluster_rows = T,
               show_rownames = F, #去掉横、纵坐标id
               show_colnames = F)
library(ggplotify)
fig2b = as.ggplot(fig2b)
fig2b

library(eulerr)
v=list(wgcna.gene,rownames(tcga.DEGs))
names(v)=c('WGCNA','TCGA DEGs')
fig2c=plot(venn(v),labels = list(col = "gray20", font = 2), 
               edges = list(col="gray60", lex=1),
               fills = list(fill = c("#BEBADA","#FDB462"), alpha = 1),
               quantities = list(cex=1, col='gray20'))
fig2c

fig2=merge_plot(merge_plot(fig2a,fig2b,labels = c('A','B')),
                   fig2c,nrow = 2,labels = c('','C'),heights = c(1,1.2))
ggsave('results/02.NvsT_DEGs/Fig2.pdf',fig2,height = 10,width = 10)



#03.风险模型########
dir.create('results/03.model')
pre.genes=intersect(wgcna.gene,rownames(tcga.DEGs))
length(pre.genes)
#348

dir.create('files/model_select')
select_gene_zscore <- function(dat1, dat2 = NULL, dat3 = NULL, 
                               a = 1, n = 100, 
                               ratio = 0.5, cut_p = 0.05, 
                               years = c(1,3,5)){
  library(timeROC)
  library(survival)
  library(glmnet)
  # library(mosaic)
  sample.index <- data.frame()
  SampleingTime <- c()
  SamplingSeed <- c()
  tra.auc <- c()
  test.auc <- c()
  geo1.auc <- c()
  geo2.auc <- c()
  all.auc <- c()
  tra.p <- c()
  test.p <- c()
  geo1.p <- c()
  geo2.p <- c()
  all.p <- c()
  tcga.dat <- dat1
  geo1.dat <- dat2
  geo2.dat <- dat3
  gene.list <- c()
  GeneNums <- c()
  for (i in a:n) {
    set.seed(i)
    par(mfrow = c(2, 3))
    myd.index <- seq(1,nrow(tcga.dat),1)
    tra.index <- sample(myd.index,size = round(nrow(tcga.dat)*ratio))
    tra.dat <- tcga.dat[tra.index,]
    test.dat <- tcga.dat[-tra.index,]
    write.table(rownames(tra.dat), file = paste0('files/model_select/tra.dat_zscore_', i, '.txt'), sep = '\t', quote = F, row.names = F)
    write.table(rownames(test.dat), file = paste0('files/model_select/test.dat_zscore_', i, '.txt'), sep = '\t', quote = F, row.names = F)
    tra.cox <- t(apply(tra.dat[,3:c(ncol(tra.dat))],2,function(x){
      vl=as.numeric(x)
      tm=tra.dat$PFI.time
      ev=tra.dat$PFI
      #ev=ifelse(ev=='Alive',0,1)
      dat=data.frame(tm,ev,vl)[which(tm > 0 & !is.na(vl)),]
      return(coxFun(dat))
    }))
    colnames(tra.cox) <- c('p.value','HR','Low 95%CI','High 95%CI')
    tra.cox <- as.data.frame(tra.cox)
    write.table(tra.cox, file = paste0('files/model_select/sig_cox_zscore_', i, '.txt'), sep = '\t', quote = F)
    cut.cox=tra.cox[which(tra.cox[,1]<cut_p),] 
    if (nrow(cut.cox) > 1) {
      print(paste("Processing....: ",i," resampling",sep=""))
      flush.console()
      geneid=rownames(cut.cox)
      geneid=geneid[which(!is.na(geneid))]
      if (length(geneid)>1) {
        sample.index<-c(sample.index,data.frame(tra.index))
        set.seed(i)
        cv.fit <- cv.glmnet(as.matrix(tra.dat[,geneid]), cbind(time=tra.dat$PFI.time, 
                                                               status=tra.dat$PFI)
                            ,family="cox", nlambda=100, alpha=1) 
        sig.coef <- coefficients(cv.fit,s=cv.fit$lambda.min)[which(coefficients(cv.fit,s=cv.fit$lambda.min)[,1]!=0),1]
        write.table(sig.coef, file = paste0('files/model_select/sig.coef_zscore_', i, '.txt'), sep = '\t', quote = F)
        if (length(names(sig.coef)>1)) {
          dat1 <- cbind(time=tra.dat$PFI.time,
                        status=tra.dat$PFI,
                        tra.dat[,match(names(sig.coef),
                                       colnames(tra.dat))])
          fmla <- as.formula(paste0("Surv(time, status) ~"
                                    ,paste0(names(sig.coef),collapse = '+')))
          cox <- coxph(fmla, data =as.data.frame(dat1))
          # lan=coef(cox)
          # print(lan)
          cox1=step(cox, trace = 0)
          lan=coef(cox1)
          write.table(lan, file = paste0('files/model_select/lan_zscore_', i, '.txt'), sep = '\t', quote = F)
          # lan=sig.coef
          final_gene=names(cox1$coefficients)
          # final_gene=names(cox$coefficients)
          GeneNums <-c(GeneNums, length(final_gene))
          
          risk.tra=as.numeric(lan%*%as.matrix(t(tra.dat[,final_gene])))
          # risk.tra=zscore(risk.tra)
          ROC.DSST <- timeROC(T=tra.dat$PFI.time,
                              delta=tra.dat$PFI,
                              marker=risk.tra,
                              cause=1,
                              weighting="marginal",
                              times=c(365*years[1],365*years[2],365*years[3]),
                              iid=TRUE)
          tra.auc=c(tra.auc,max(ROC.DSST$AUC))
          trap=plotKMCox(data.frame(tra.dat$PFI.time,tra.dat$PFI,ifelse(risk.tra>=median(risk.tra),'H','L')))
          tra.p=c(tra.p,trap)
          risk.test=as.numeric(lan%*%as.matrix(t(test.dat[,final_gene])))
          # risk.test=zscore(risk.test)
          ROC.DSST1=timeROC(T=test.dat$PFI.time,delta=test.dat$PFI,marker=risk.test,cause=1,weighting="marginal",
                            times=c(365*years[1],365*years[2],365*years[3]),iid=TRUE)
          test.auc=c(test.auc,max(ROC.DSST1$AUC))
          testp=plotKMCox(data.frame(test.dat$PFI.time,test.dat$PFI,ifelse(risk.test>=median(risk.test),'H','L')))
          test.p=c(test.p,testp)
          risk.all=as.numeric(lan%*%as.matrix(t(tcga.dat[,final_gene])))
          # risk.all=zscore(risk.all)
          ROC.DSST3=timeROC(T=tcga.dat$PFI.time,delta=tcga.dat$PFI,marker=risk.all,cause=1,weighting="marginal",
                            times=c(365*years[1],365*years[2],365*years[3]),iid=TRUE)
          all.auc=c(all.auc,max(ROC.DSST3$AUC))
          allp=plotKMCox(data.frame(tcga.dat$PFI.time,tcga.dat$PFI,ifelse(risk.all>=median(risk.all),'H','L')))
          all.p=c(all.p,allp)
          # final_gene1=as.character(gene.type[final_gene,1])
          
          if (length(intersect(final_gene,colnames(geo1.dat)))==length(final_gene)) {
            risk.geo1=as.numeric(lan%*%as.matrix(t(geo1.dat[,intersect(final_gene,colnames(geo1.dat))])))
            # risk.geo1=zscore(risk.geo1)
            ROC.DSST2=timeROC(T=geo1.dat$PFI.time,delta=geo1.dat$PFI,marker=risk.geo1,cause=1,weighting="marginal",
                              times=c(365*years[1],365*years[2],365*years[3]),iid=TRUE)
            geo1.auc=c(geo1.auc,max(ROC.DSST2$AUC))
            geop=plotKMCox(data.frame(geo1.dat$PFI.time,geo1.dat$PFI,ifelse(risk.geo1>=median(risk.geo1),'H','L')))
            geo1.p=c(geo1.p,geop)
          }else{
            geo1.auc=c(geo1.auc,NA)
            geo1.p=c(geo1.p,NA)
          }
          
          if (length(intersect(final_gene,colnames(geo2.dat)))==length(final_gene)) {
            risk.geo2=as.numeric(lan%*%as.matrix(t(geo2.dat[,intersect(final_gene,colnames(geo2.dat))])))
            # risk.geo2=zscore(risk.geo2)
            ROC.DSST4=timeROC(T=geo2.dat$PFI.time,delta=geo2.dat$PFI,marker=risk.geo2,cause=1,weighting="marginal",
                              times=c(365*years[1],365*years[2],365*years[3]),iid=TRUE)
            geo2.auc=c(geo2.auc,max(ROC.DSST4$AUC))
            geop=plotKMCox(data.frame(geo2.dat$PFI.time,geo2.dat$PFI,ifelse(risk.geo2>=median(risk.geo2),'H','L')))
            geo2.p=c(geo2.p,geop)
          }else{
            geo2.auc=c(geo2.auc,NA)
            geo2.p=c(geo2.p,NA)
          }
          print(c('AUC',max(ROC.DSST$AUC),max(ROC.DSST1$AUC),max(ROC.DSST3$AUC)))
          print(c('P',trap,testp,allp))
          print(c('num',length(final_gene)))
          print("........")
          SampleingTime=c(SampleingTime,i)
          gene.list=c(gene.list,as.character(final_gene))
          SamplingSeed=c(SamplingSeed,rep(i,length(final_gene)))
        }
      }
    }
  }
  myd.clustering.df=data.frame("SamplingTime"=SampleingTime,
                               "TrainRiskP"=tra.p,"TrainRiskAUC"=tra.auc,
                               "TestRiskP"=test.p,"TestRiskAUC"=test.auc,
                               "TCGARiskP"=all.p,"TCGARiskAUC"=all.auc,
                               "GEO1RiskP"=geo1.p,"GEO1RiskAUC"=geo1.auc,
                               "GEO2RiskP"=geo2.p,"GEO2RiskAUC"=geo2.auc,
                               "GeneNums"=GeneNums)
  sample.index=as.data.frame(sample.index)
  colnames(sample.index)=paste("seed",SampleingTime,sep="")
  myd.clustering.genes=data.frame("SamplingSeed"=SamplingSeed,"Genes"=gene.list)
  return(list(myd.clustering.df,sample.index,myd.clustering.genes))
}
com.genes=Reduce(intersect,list(rownames(tcga.exp),rownames(mskcc.exp),pre.genes))
length(com.genes)

tcga_model_data <- cbind(tcga.cli[, c("PFI.time", "PFI")],
                         t(tcga.exp[com.genes, tcga.cli$Samples]))
colnames(tcga_model_data) <- gsub('-', '_', colnames(tcga_model_data))
dim(tcga_model_data)

mskcc_model_data <- cbind(mskcc.cli[, c("DFS.time", "DFS")],
                          t(mskcc.exp[com.genes, mskcc.cli$Samples]))
colnames(mskcc_model_data) <- gsub('-', '_', colnames(mskcc_model_data))
dim(mskcc_model_data)
colnames(mskcc_model_data)[1:2]=c("PFI.time", "PFI")
mskcc_model_data$PFI.time=mskcc_model_data$PFI.time*30

# myd_exp_resampling <- select_gene_zscore(dat1 = tcga_model_data,
#                                          dat2 = mskcc_model_data,
#                                          # dat3 = GSE84437_model_data,
#                                          a = 1,
#                                          n = 50,
#                                          ratio = 0.5,
#                                          cut_p = 0.05,
#                                          years = c(1:5))
num <- 37   #OK
tra.samples <- rownames(read.delim(paste0('files/model_select/tra.dat_zscore_',num,'.txt'), 
                                   header = T, row.names = 1, stringsAsFactors = F))
test.samples <- rownames(read.delim(paste0('files/model_select/test.dat_zscore_',num,'.txt'),
                                    header = T, row.names = 1, stringsAsFactors = F))
tra.data <- tcga_model_data[tra.samples, ]
dim(tra.data)
test.data <- tcga_model_data[test.samples, ]
dim(test.data)

colnames(tcga.cli)
tcga.cli.chisq=tcga.cli[c(tra.samples,test.samples),]
tcga.cli.chisq$cohort=c(rep(c('Train','Test'),c(length(tra.samples),length(test.samples))))
write.csv(tcga.cli.chisq[,c("cohort","Age","T.stage","N.stage","M.stage",'PFI',"PFI.time")],
          'results/03.model/chisq_pre.csv',row.names = F)


tra.cox=cox_batch(dat = tcga.exp[com.genes,tra.samples],
                  time = tcga.cli[tra.samples,]$PFI.time,event = tcga.cli[tra.samples,]$PFI)
tra.cox=na.omit(tra.cox)
head(tra.cox)
rownames(tra.cox)=gsub('-','_',rownames(tra.cox))
p_cutoff=0.05
table(tra.cox$p.value<p_cutoff)
tra.cox.fit=tra.cox[tra.cox$p.value<p_cutoff,]

#########lasso
library(glmnet)
set.seed(num)
fit1=glmnet(as.matrix(tra.data[,rownames(tra.cox.fit)])
            ,cbind(time=tra.data$PFI.time,status=tra.data$PFI)
            ,family="cox"
            ,nlambda=100
            , alpha=1) 

cv.fit<-cv.glmnet(as.matrix(tra.data[,rownames(tra.cox.fit)])
                  ,cbind(time=tra.data$PFI.time,status=tra.data$PFI)
                  ,family="cox"
                  ,nlambda=100
                  , alpha=1)
sig.coef <- coefficients(cv.fit,s=cv.fit$lambda.min)[which(coefficients(cv.fit,s=cv.fit$lambda.min)[,1]!=0),1]
cv.fit$lambda.min
#0.03000994
names(sig.coef)

pdf('results/03.model/LASSO.pdf',height = 5,width = 10)
par(mfrow=c(1,2))
plot(fit1)
plot(cv.fit)
dev.off()

fmla <- as.formula(paste0("Surv(PFI.time, PFI) ~",paste0(names(sig.coef),collapse = '+')))
cox <- coxph(fmla, data =as.data.frame(tra.data))
cox=step(cox)

module.coxforest=ggforest(cox, data = tra.data, 
                          main = "Hazardratio", fontsize =1.0, 
                          noDigits = 2)
module.coxforest
ggsave('results/03.model/module.coxforest.pdf',module.coxforest,height = 5,width = 10)

lan <- coef(cox)
lan
paste0(round(lan, 3), '*', names(lan),collapse = '+')
#0.285*HOXC4+0.196*PAQR6+-0.572*SLC5A8
gene.coef=data.frame(gene=names(lan),coef=as.numeric(lan))
gene.coef
gene.coef$Type=ifelse(gene.coef$coef>0,'Risk','Protective')
gene.coef.fig=ggplot(gene.coef, aes(x = coef, y = reorder(gene,coef), fill =Type)) +
  geom_bar(stat = "identity") +
  scale_fill_manual(values = c("#FDB462", "#80B1D3")) +
  labs(x = 'coefficient', y = "") +
  geom_text(aes(label = round(coef,2),hjust =2), data = subset(gene.coef, coef > 0))+ 
  geom_text(aes(label = round(coef,2), hjust = -1), data = subset(gene.coef, coef < 0))+  
  theme_bw()+ theme(text = element_text(family = 'Times',size = 14,face = 'bold'),legend.position = 'top')
gene.coef.fig
ggsave('results/03.model/gene.coef.pdf',gene.coef.fig,height =5,width = 7)


##训练集########
risktype.col=c("orange","blue")
risk.tra=as.numeric(lan%*%as.matrix(t(tra.data[tra.samples,names(lan)])))
tra.risktype.cli=data.frame(tcga.cli[tra.samples,],Riskscore=risk.tra)

# #######最佳阈值
tra.data.point <- surv_cutpoint(tra.risktype.cli, time = "PFI.time", event = "PFI",
                                variables = 'Riskscore')
tra.cutoff <- as.numeric(summary(tra.data.point)[1])
tra.cutoff
tra.risktype.cli$Risktype=ifelse(tra.risktype.cli$Riskscore>tra.cutoff,'High','Low')

#tra.risktype.cli$Risktype=ifelse(tra.risktype.cli$Riskscore>median(risk.tra),'High','Low')
tra.km=ggplotKMCox(data.frame(tra.risktype.cli$PFI.time/365,
                              tra.risktype.cli$PFI,
                              tra.risktype.cli$Risktype),
                   palette = risktype.col,show_confint = F,title = 'Train cohort')
tra.km

tra.roc=ggplotTimeROC(tra.risktype.cli$PFI.time,
                      tra.risktype.cli$PFI,
                      tra.risktype.cli$Riskscore,mks = c(1:5))
tra.roc



########验证集########
risk.test=as.numeric(lan%*%as.matrix(t(test.data[test.samples,names(lan)])))
test.risktype.cli=data.frame(tcga.cli[test.samples,],Riskscore=risk.test)

#######最佳阈值
test.data.point <- surv_cutpoint(test.risktype.cli, time = "PFI.time", event = "PFI",
                                 variables = 'Riskscore')
test.cutoff <- as.numeric(summary(test.data.point)[1])
test.cutoff
test.risktype.cli$Risktype=ifelse(test.risktype.cli$Riskscore>test.cutoff,'High','Low')

#test.risktype.cli$Risktype=ifelse(test.risktype.cli$Riskscore>median(risk.test),'High','Low')
test.km=ggplotKMCox(data.frame(test.risktype.cli$PFI.time/365,
                               test.risktype.cli$PFI,
                               test.risktype.cli$Risktype),
                    palette = risktype.col,show_confint = F,title = 'Test cohort')
test.km


test.roc=ggplotTimeROC(test.risktype.cli$PFI.time,
                       test.risktype.cli$PFI,
                       test.risktype.cli$Riskscore,mks = c(1:5))
test.roc




#######TCGA全部########
risk.tcga=as.numeric(lan%*%as.matrix(t(tcga_model_data[tcga.cli$Samples,names(lan)])))
tcga.risktype.cli=data.frame(tcga.cli,Riskscore=risk.tcga)

#######最佳阈值
tcga.data.point <- surv_cutpoint(tcga.risktype.cli, time = "PFI.time", event = "PFI",
                                 variables = 'Riskscore')
tcga.cutoff <- as.numeric(summary(tcga.data.point)[1])
tcga.cutoff
tcga.risktype.cli$Risktype=ifelse(tcga.risktype.cli$Riskscore>tcga.cutoff,'High','Low')

#tcga.risktype.cli$Risktype=ifelse(tcga.risktype.cli$Riskscore>median(risk.tcga),'High','Low')
tcga.km=ggplotKMCox(data.frame(tcga.risktype.cli$PFI.time/365,
                               tcga.risktype.cli$PFI,
                               tcga.risktype.cli$Risktype),
                    palette = risktype.col,show_confint = F,title = 'TCGA cohort')
tcga.km

tcga.roc=ggplotTimeROC(tcga.risktype.cli$PFI.time,
                       tcga.risktype.cli$PFI,
                       tcga.risktype.cli$Riskscore,mks = c(1:5))
tcga.roc

##验证集########

risk.mskcc=as.numeric(lan%*%as.matrix(t(mskcc_model_data[mskcc.cli$Samples,names(lan)])))
mskcc.risktype.cli=data.frame(mskcc.cli,Riskscore=risk.mskcc)

mskcc.data.point <- surv_cutpoint(mskcc.risktype.cli, time = "DFS.time", event = "DFS",
                                  variables = 'Riskscore')
mskcc.cutoff <- as.numeric(summary(mskcc.data.point)[1])
mskcc.cutoff
mskcc.risktype.cli$Risktype=ifelse(mskcc.risktype.cli$Riskscore>mskcc.cutoff,'High','Low')

#mskcc.risktype.cli$Risktype=ifelse(mskcc.risktype.cli$Riskscore>median(risk.mskcc),'High','Low')
mskcc.km=ggplotKMCox(data.frame(mskcc.risktype.cli$DFS.time/365,
                                mskcc.risktype.cli$DFS,
                                mskcc.risktype.cli$Risktype),
                     palette = risktype.col,show_confint = F,title = 'MSKCC cohort')
mskcc.km

mskcc.roc=ggplotTimeROC(mskcc.risktype.cli$DFS.time,
                        mskcc.risktype.cli$DFS,
                        mskcc.risktype.cli$Riskscore,mks = c(1:5))
mskcc.roc

model.plot=merge_plot(tra.km,test.km,tcga.km,mskcc.km,tra.roc,test.roc,tcga.roc,mskcc.roc,
                         ncol=4,nrow=2,labels = LETTERS[4:7])
ggsave('results/03.model/model.plot.pdf',model.plot,height = 10,width = 18)

#04.列线图#########
dir.create('results/04.nomogram')
head(tcga.risktype.cli)
tcga_cox_datas=tcga.risktype.cli
colnames(tcga_cox_datas)
table(tcga_cox_datas$Age1)

table(tcga_cox_datas$T.stage)
tcga_cox_datas$T.stage[tcga_cox_datas$T.stage=='T1'|tcga_cox_datas$T.stage=='T2']<-'T1+T2'
tcga_cox_datas$T.stage[tcga_cox_datas$T.stage=='T3'|tcga_cox_datas$T.stage=='T4']<-'T3+T4'
table(tcga_cox_datas$N.stage)
table(tcga_cox_datas$M.stage)


#Age
tcga_cox_datas=crbind2DataFrame(tcga_cox_datas)
Age_sig_cox <- summary(coxph(formula=Surv(OS.time, OS)~Age,
                             data=tcga_cox_datas))
Age_sig_cox_dat <- data.frame(Names=rownames(Age_sig_cox[[8]]),
                              HR = round(Age_sig_cox[[7]][,2],3),
                              lower.95 = round(Age_sig_cox[[8]][,3],3),
                              upper.95 = round(Age_sig_cox[[8]][,4],3),
                              p.value=round(Age_sig_cox[[7]][,5],3))
Age_sig_cox_dat




#T.stage
T.stage_sig_cox <- summary(coxph(formula=Surv(OS.time, OS)~T.stage,
                                 data=tcga_cox_datas))
T.stage_sig_cox_dat <- data.frame(Names=rownames(T.stage_sig_cox[[8]]),
                                  HR = round(T.stage_sig_cox[[7]][,2],3),
                                  lower.95 = round(T.stage_sig_cox[[8]][,3],3),
                                  upper.95 = round(T.stage_sig_cox[[8]][,4],3),
                                  p.value=round(T.stage_sig_cox[[7]][,5],3))
T.stage_sig_cox_dat

#N.stage
N.stage_sig_cox <- summary(coxph(formula=Surv(OS.time, OS)~N.stage,
                                 data=tcga_cox_datas))
N.stage_sig_cox_dat <- data.frame(Names=rownames(N.stage_sig_cox[[8]]),
                                  HR = round(N.stage_sig_cox[[7]][,2],3),
                                  lower.95 = round(N.stage_sig_cox[[8]][,3],3),
                                  upper.95 = round(N.stage_sig_cox[[8]][,4],3),
                                  p.value=round(N.stage_sig_cox[[7]][,5],3))
N.stage_sig_cox_dat

#M.stage
M.stage_sig_cox <- summary(coxph(formula=Surv(OS.time, OS)~M.stage,
                                 data=tcga_cox_datas))
M.stage_sig_cox_dat <- data.frame(Names=rownames(M.stage_sig_cox[[8]]),
                                  HR = round(M.stage_sig_cox[[7]][,2],3),
                                  lower.95 = round(M.stage_sig_cox[[8]][,3],3),
                                  upper.95 = round(M.stage_sig_cox[[8]][,4],3),
                                  p.value=round(M.stage_sig_cox[[7]][,5],3))
M.stage_sig_cox_dat
#riskscore
riskscore_sig_cox<-summary(coxph(formula=Surv(OS.time, OS)~Riskscore,
                                 data=tcga_cox_datas))
riskscore_sig_cox_dat <- data.frame(Names=rownames(riskscore_sig_cox[[8]]),
                                    HR = round(riskscore_sig_cox[[7]][,2],3),
                                    lower.95 = round(riskscore_sig_cox[[8]][,3],3),
                                    upper.95 = round(riskscore_sig_cox[[8]][,4],3),
                                    p.value=round(riskscore_sig_cox[[7]][,5],3))
riskscore_sig_cox_dat

sig_cox_dat <- rbind(Age_sig_cox_dat,
                     T.stage_sig_cox_dat,
                     N.stage_sig_cox_dat,
                     M.stage_sig_cox_dat,
                     riskscore_sig_cox_dat)
data.sig <- data.frame(Features=sig_cox_dat$Names,
                       p.value=sig_cox_dat$p.value,
                       sig_cox_dat$HR,
                       sig_cox_dat$lower.95,
                       sig_cox_dat$upper.95)
data.sig <- crbind2DataFrame(data.sig)
rownames(data.sig) <-c('Age',"T.stage","N.stage","M.stage",'Riskscore')
data.sig$Features=rownames(data.sig)
data.sig
data.sig$p.value=ifelse(data.sig$p.value<0.001,'<0.001',data.sig$p.value)
pdf('results/04.nomogram/Univariate.pdf',height = 4,width = 6,onefile = F)
my_forestplot(data.sig,xlog = T,colgap =5,lineheight = 9,zero = 1,
                 boxsize = .2,lwd.zero=1,lwd.ci=1.5,lwd.xaxis=1,
                 box_col='orange',summary_col="black",lines_col='black',zero_col='grey',
                 xlab='Hazard Ratio',lty.ci = 6,graph.pos =4)
dev.off()



#########多因素
#T.stage +  N.stage +M.stage
muti_sig_cox <- summary(coxph(formula=Surv(OS.time, OS)~T.stage +Riskscore, 
                              data=tcga_cox_datas))
muti_cox_dat <- data.frame(Names=rownames(muti_sig_cox[[8]]),
                           HR = round(muti_sig_cox[[7]][,2],3),
                           lower.95 = round(muti_sig_cox[[8]][,3],3),
                           upper.95 = round(muti_sig_cox[[8]][,4],3),
                           p.value=round(muti_sig_cox[[7]][,5],3))
data.muti <- data.frame(Features=muti_cox_dat$Names,
                        p.value=muti_cox_dat$p.value,
                        muti_cox_dat$HR,
                        muti_cox_dat$lower.95,
                        muti_cox_dat$upper.95)
data.muti <- crbind2DataFrame(data.muti)
data.muti
rownames(data.muti) <- c('T.stage','Riskscore')
data.muti$Features=rownames(data.muti)
data.muti
data.muti$p.value=ifelse(data.muti$p.value<0.001,'<0.001',data.muti$p.value)
pdf('results/04.nomogram/Multivariate.pdf',height = 4,width =6,onefile = F)
my_forestplot(data.muti,xlog = T,colgap =5,lineheight = 9,zero = 1,
                 boxsize = .2,lwd.zero=1,lwd.ci=1.5,lwd.xaxis=1,
                 box_col='orange',summary_col="black",lines_col='black',zero_col='grey',
                 xlab='Hazard Ratio',lty.ci = 6,graph.pos =4)
dev.off()
save(tcga_cox_datas,file = 'results/tcga_cox_datas.RData')





save.image(file = 'project.RData')
#05.免疫微环境#########
dir.create('results/05.TME')
tcga.est=read.delim('results/05.TME/ESTIMATE_score.txt',row.names = 1)
head(tcga.est)



est.df=cbind.data.frame(tcga.est[tcga.risktype.cli$Samples,-4],Risktype=tcga.risktype.cli$Risktype)
head(est.df)
est.df=melt(est.df)
head(est.df)

fig5a=ggplot(est.df,aes(x=variable, y=value,fill=Risktype)) +
  geom_boxplot(notch = T)+
  scale_fill_manual(values = risktype.col)+   #箱线图填充颜色
  ggpubr::stat_compare_means(aes(group=Risktype), label = "p.signif", method = 't.test')+
  labs(x="", y = "Score", fill = "Risktype") +
  #theme_light()+
  theme_classic()+
  theme(legend.position = 'top',
        text = element_text(family = 'Times',color = "black",size = 15,face = 'bold'),
        axis.text.x = element_text(angle = 45, hjust = 1)) # 将图表标题居中

tcga.cibersort=read.delim('results/05.TME/TCGA_CIBERSORT_Results.txt',row.names = 1,check.names = F)
head(tcga.cibersort)
# table(tcga.cibersort$`P-value`<0.05)
tme.df2=tcga.cibersort[tcga.risktype.cli$Samples,1:22]
tme.df2=as.data.frame(tme.df2)
tme.df2$Risktype=tcga.risktype.cli$Risktype
tme.df2=melt(tme.df2)
head(tme.df2)
table(tme.df2$variable)
fig5b=tme.df2 %>%
  ggplot(aes(x=variable,y=value,fill=Risktype))+
  geom_boxplot()+stat_compare_means(aes(group=Risktype), label = "p.signif", method = 't.test')+
  scale_fill_manual(values =risktype.col)+
  xlab('')+ylab('Score')+ggtitle('CIBERSORT')+
  theme_classic()+theme(legend.position = 'none',
                        text = element_text(family = 'Times',size = 14),
                        axis.text.x = element_text(angle = 45, hjust = 1))
fig5b




load("results/05.TME/tcga_immu_ssgsea.RData")
tcga.immu.ssgsea[1:5,1:5]
TME.df1=cbind.data.frame(tcga.immu.ssgsea[tcga.risktype.cli$Samples,],Risktype=tcga.risktype.cli$Risktype)
head(TME.df1)
TME.df1=melt(TME.df1)
head(TME.df1)

fig5c=ggplot(TME.df1,aes(x=variable, y=value,fill=Risktype)) +
  geom_boxplot()+
  #scale_color_manual(values = sub.col) +  #箱线图颜色
  scale_fill_manual(values =risktype.col)+   #箱线图填充颜色
  ggpubr::stat_compare_means(aes(group=Risktype), label = "p.signif", method = 't.test')+
  labs(x="", y = "Score", fill = "Risktype") +
  theme_classic()+ggtitle('ssGSEA')+
  theme(legend.position = 'none',
        text = element_text(family = 'Times',size = 14),
        axis.text.x = element_text(angle = 45, hjust = 1)) # 将图表标题居中
fig5c


##免疫检查点
icgs.gene=read.xlsx('public/79ICGs_PMID32814346.xlsx',check.names = F)
head(icgs.gene)
icgs.gene=icgs.gene[,c(1,3)]
table(icgs.gene$Role.with.Immunity)
icgs.gene=icgs.gene[icgs.gene$Symbol%in%rownames(tcga.exp),]
icgs.gene=icgs.gene[icgs.gene$Role.with.Immunity=='Inhibit',]

TME.df2=cbind.data.frame(t(tcga.exp[icgs.gene$Symbol,tcga.risktype.cli$Samples]),Risktype=tcga.risktype.cli$Risktype)
head(TME.df2)
TME.df2=melt(TME.df2)
head(TME.df2)



fig5d=ggplot(TME.df2,aes(x=variable, y=value,fill=Risktype)) +
  geom_boxplot()+
  #scale_color_manual(values = sub.col) +  #箱线图颜色
  scale_fill_manual(values =risktype.col)+   #箱线图填充颜色
  ggpubr::stat_compare_means(aes(group=Risktype), label = "p.signif", method = 't.test')+
  labs(x="", y = "log2(TPM+1)", fill = "Risktype") +
  theme_classic()+
  theme(legend.position = 'top',
        text = element_text(family = 'Times',size = 14),
        axis.text.x = element_text(angle = 45, hjust = 1)) # 将图表标题居中
fig5d


#####肿瘤突变负荷
tcga.maf=getTCGAMAFByCode('PRAD')
tcga.TMB=tmb(tcga.maf)
head(tcga.TMB)
tcga.TMB=data.frame(Samples=paste0(tcga.TMB$Tumor_Sample_Barcode,'-01'),TMB=tcga.TMB$total_perMB_log)
tcga.TMB=merge(tcga.TMB,tcga.risktype.cli,by='Samples')

# fig5d=tcga.TMB%>%drop_na(TMB)%>%
#   ggplot(aes(x=Risktype,y=TMB,fill=Risktype))+
#   scale_fill_manual(values = risktype.col)+ylab('log10(TMB)')+
#   geom_boxplot()+ stat_compare_means(aes(group=Risktype), label = "p.format", method = 'wilcox.test')+
#   theme_bw()+theme(text = element_text(family = 'Times',size=14),legend.position = 'none')
# fig5d


fig5e=ggviolin(tcga.TMB, x = "Risktype", y = "TMB", fill = "Risktype",
                  add = "boxplot")+scale_fill_manual(values =rev(risktype.col))+ylab('log10(TMB)')+
           ggpubr::stat_compare_means(aes(group=Risktype), label = "p.format", method = 't.test')+
           theme(legend.position = "none",text = element_text(family = 'Times',size = 14))
fig5e


fig5=merge_plot(merge_plot(fig5a,fig5b,widths = c(1,3),labels = c('A','B'),align = 'h'),fig5c,
                   merge_plot(fig5d,fig5e,widths = c(2,1),labels = c('D','E')),
                   nrow=3,labels = c('','C',''),heights = c(1,1.2,1))
ggsave('results/05.TME/Fig5.pdf',fig5,height = 14,width = 14)


# # ##TIDE评分###
# tcga_tide_res<-read.csv('results/05.TME/tcga.tide.res.csv',row.names = 1,stringsAsFactors = F)
# head(tcga_tide_res)
# dim(tcga_tide_res)
# 
# TIDE.df=data.frame(tcga_tide_res[tcga.risktype.cli$Samples,],
#                    tcga.risktype.cli)
# head(TIDE.df)
# table(TIDE.df$Responder,TIDE.df$Risktype)
# chisq.test(table(TIDE.df$Responder,TIDE.df$Risktype))
# tide.responder=prop.table(table(TIDE.df$Responder,TIDE.df $Risktype),margin=2)
# tide.responder=melt(tide.responder)
# tide.responder
# ggplot(tide.responder, aes(x= Var2, y=value, fill=Var1))+
#   geom_bar(stat = "identity")+xlab('Riskscore')+ylab('Percentage')+
#   scale_fill_manual(values = pal_simpsons()(9)[5:6],name='Responder')+
#   theme_bw()+geom_text(data=tide.responder,aes(label=paste(round(100*value,2),'%',sep='')))+
#   theme(text = element_text(family = 'Times',size = 12),legend.position = 'top',
#         panel.grid.major = element_blank(), panel.grid.minor = element_blank())
# 
# ggplot(TIDE.df,aes(x=Risktype,y=TIDE,fill=Risktype))+
#   geom_violin()+
#   geom_boxplot(width=0.2,position=position_dodge(0.9),outlier.colour = NA,fill="white")+
#   stat_compare_means(aes(group=Risktype), label = "p.format", method = 't.test')+
#   scale_fill_manual(values =risktype.col)+theme_bw()+ylab('TIDE')+
#   theme(text = element_text(family = 'Times',size = 15),legend.position = 'none',
#         panel.grid.major = element_blank(), panel.grid.minor = element_blank())

# 
# 
# ##IPS得分
# library(IOBR)
# IPS.res=IPS_calculation(project = 'PRAD',eset = tcga.exp,plot = F)
# head(IPS.res)
# dim(IPS.res)
# 
# IPS.df=data.frame(IPS.res[tcga.risktype.cli$Samples,],
#                   tcga.risktype.cli)
# 
# 
# ggviolin(IPS.df, x = "Risktype", y = "IPS", fill = "Risktype",
#          add = "boxplot")+scale_fill_manual(values =rev(risktype.col))+
#   ggpubr::stat_compare_means(aes(group=Risktype), label = "p.format", method = 'wilcox.test')+
#   theme(legend.position = "none",text = element_text(family = 'Times',size = 14))









#06.突变特征和通路差异##########
dir.create('results/06.Pathway_difference')
##GSEA ############
tcga.geneList=my_getGeneFC(gene.exp=tcga.exp[,tcga.risktype.cli$Samples],group=tcga.risktype.cli$Risktype
                        ,ulab='High',dlab = 'Low')
h.all.gmt<-read.gmt("gmt/c5.go.bp.v2023.2.Hs.entrez.gmt")
set.seed(123)
tcga.geneList.gsea<-GSEA(tcga.geneList,TERM2GENE = h.all.gmt,seed=T)
tcga.geneList.gsea.res=tcga.geneList.gsea@result
write.xlsx(tcga.geneList.gsea.res,'results/06.Pathway_difference/risktype_GSEA.xlsx',overwrite = T)
head(tcga.geneList.gsea.res)
table(tcga.geneList.gsea.res$NES>0)
# FALSE  TRUE 
# 21     7 
tcga.geneList.gsea.res$group=ifelse(tcga.geneList.gsea.res$NES>0,"Activated","Suppressed")
topPathways = tcga.geneList.gsea.res %>% group_by(group) %>% slice_max(n =10, order_by = abs(NES))

library(GseaVis)
pdf('results/06.Pathway_difference/risktype_GSEA.pdf',height = 6,width = 8,onefile = F)
gseaNb(object = tcga.geneList.gsea,subPlot =3,
           geneSetID = topPathways$ID[topPathways$NES>0][c(1,5,6)],
           termWidth = 35,kegg = F,
           legend.position = c(0.8,0.8),
           addPval = T,addPoint = T,
           pvalX = 0.15,pvalY = 0.1)

dev.off()

##gsva##########
tcga.pathway.ssgsea=tcga.hall.ssGSEA
rownames(tcga.pathway.ssgsea)=gsub('HALLMARK_','',rownames(tcga.pathway.ssgsea))

hallmark_anno1=read.xlsx('HALLMARK_geneset.xlsx',check.names = F)
table(hallmark_anno1$Process.category)
hallmark_anno=data.frame(category=hallmark_anno1$Process.category[order(hallmark_anno1$Process.category)])
rownames(hallmark_anno)=hallmark_anno1$Hallmark.name[order(hallmark_anno1$Process.category)]
head(hallmark_anno)

category.col=pal_rickandmorty()(12)[1:8]
names(category.col)=names(table(hallmark_anno$category))

clinical.col=risktype.col
names(clinical.col)=c('High','Low')

cli_anno2=data.frame(Risktype=tcga.risktype.cli[order(tcga.risktype.cli$Riskscore),'Risktype'])
rownames(cli_anno2)=tcga.risktype.cli[order(tcga.risktype.cli$Riskscore),'Samples']


pdf('results/06.Pathway_difference/hallmark_heatmap.pdf',height = 6.5,width = 10,onefile = F)
pheatmap(tcga.pathway.ssgsea[rownames(hallmark_anno),rownames(cli_anno2)],
         scale = 'row',name = 'ssGSEA score',
         annotation_col = cli_anno2,annotation_row = hallmark_anno,
         col = circlize::colorRamp2(c(-5, 0, 5), c('#1A5592','white',"orange")),
         annotation_colors = list(category=category.col,Risktype=clinical.col),
         cluster_cols = F, cluster_rows = F,
         show_rownames = T,show_colnames = F)
dev.off()


##基因组特征########

####其他基因组特征
tcga.character=read.delim('source/PMC5982584_supplement_2.txt')
table(tcga.character$`TCGA Study`)
tcga.character$Samples=paste0(rownames(tcga.character),'-01')
rownames(tcga.character)=tcga.character$Samples
tcga.character=merge(tcga.character,tcga.risktype.cli,by='Samples')
colnames(tcga.character)



p1=tcga.character %>%drop_na(`Homologous Recombination Defects`)%>%
  ggplot(aes(x=Risktype,   y=`Homologous Recombination Defects`,fill=Risktype))+
  scale_fill_manual(values = risktype.col)+
  geom_boxplot()+ stat_compare_means(aes(group=Risktype), label = "p.format", method = 't.test')+
  theme_bw()+theme(text = element_text(family = 'Times',size=14),legend.position = 'none')
p1



p2=tcga.character %>%drop_na(`Nonsilent Mutation Rate`)%>%subset(`Nonsilent Mutation Rate`<10)%>%
  ggplot(aes(x=Risktype,y=`Nonsilent Mutation Rate`,fill=Risktype))+
  scale_fill_manual(values = risktype.col)+
  geom_boxplot()+ stat_compare_means(aes(group=Risktype), label = "p.format", method = 't.test')+
  theme_bw()+theme(text = element_text(family = 'Times',size=14),legend.position = 'none')
p2



p3=tcga.character %>%drop_na(`Number of Segments`)%>%
  ggplot(aes(x=Risktype,y=`Number of Segments`,fill=Risktype))+
  scale_fill_manual(values = risktype.col)+
  geom_boxplot()+ stat_compare_means(aes(group=Risktype), label = "p.format", method = 't.test')+
  theme_bw()+theme(text = element_text(family = 'Times',size=14),legend.position = 'none')
p3


p4=tcga.character %>%drop_na(`Fraction Altered`)%>%
  ggplot(aes(x=Risktype,y=`Fraction Altered`,fill=Risktype))+
  scale_fill_manual(values = risktype.col)+
  geom_boxplot()+ stat_compare_means(aes(group=Risktype), label = "p.format", method = 't.test')+
  theme_bw()+theme(text = element_text(family = 'Times',size=14),legend.position = 'none')
p4

p5=tcga.character%>%drop_na(Proliferation)%>%
  ggplot(aes(x=Risktype,y=Proliferation,fill=Risktype))+
  scale_fill_manual(values = risktype.col)+
  geom_boxplot()+ stat_compare_means(aes(group=Risktype), label = "p.format", method = 't.test')+
  theme_bw()+theme(text = element_text(family = 'Times',size=14),legend.position = 'none')
p5



fig6c=merge_plot(p2,p3,p4,p5,p1,nrow=2,ncol=3,labels = 'C')

pdf('results/06.Pathway_difference/character_boxplot.pdf',height = 6,width = 8,onefile = F)
fig6c
dev.off()



##体细胞突变差异######
tcga.risktype.cli.use=tcga.risktype.cli
table(tcga.risktype.cli.use$Risktype)
colnames(tcga.risktype.cli.use)[1]='Tumor_Sample_Barcode'
tcga.risktype.cli.use$Tumor_Sample_Barcode=substr(tcga.risktype.cli.use$Tumor_Sample_Barcode,1,12)
tcga.risktype.cli.use.high=tcga.risktype.cli.use[which(tcga.risktype.cli.use$Risktype=='High'),]
tcga.risktype.cli.use.low=tcga.risktype.cli.use[which(tcga.risktype.cli.use$Risktype=='Low'),]

write.table(tcga.risktype.cli.use.high,file='results/tcga.risktype.cli.high.txt')
write.table(tcga.risktype.cli.use.low,file='results/tcga.risktype.cli.low.txt')

tcga.maf1=subsetMaf(tcga.maf,tsb=intersect(tcga.maf@data$Tumor_Sample_Barcode,tcga.risktype.cli.use.high$Tumor_Sample_Barcode))
tcga.maf1<-read.maf(tcga.maf1@data,isTCGA=T,clinicalData = 'results/tcga.risktype.cli.high.txt')
tcga.maf1@clinical.data

tcga.maf2=subsetMaf(tcga.maf,tsb=intersect(tcga.maf@data$Tumor_Sample_Barcode,tcga.risktype.cli.use.low$Tumor_Sample_Barcode))
tcga.maf2<-read.maf(tcga.maf2@data,isTCGA=T,clinicalData = 'results/tcga.risktype.cli.low.txt')
tcga.maf2@clinical.data


######两个不同队列的差异突变基因，检验方式为fisher检验。
mdf_cp=mafCompare(tcga.maf1,tcga.maf2,m1Name = 'High',m2Name = 'Low')
mdf_cp$results
write.csv(mdf_cp$results,'results/06.Pathway_difference/maf_compare.csv')

pdf('results/06.Pathway_difference/MAF_forestPlot.pdf',height = 5,width = 6,onefile = F)
forestPlot(mafCompareRes = mdf_cp,color = c('royalblue', 'maroon'))
dev.off()



save.image(file = 'project.RData')



