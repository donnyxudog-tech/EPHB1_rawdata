###富集分析
my_clusterProfiler=function(genes,keytype='SYMBOL',minGSSize=10,maxGSSize = 500,
pAdjustMethod = "BH",pvalueCutoff=0.05,qvalueCutoff = 0.5){
  library(org.Hs.eg.db)
  library(clusterProfiler)
  eg <- bitr(genes, fromType=keytype, toType=c("ENTREZID","ENSEMBL"), OrgDb="org.Hs.eg.db");
  
  kegg_enrich=clusterProfiler::enricher(eg$ENTREZID, pvalueCutoff = pvalueCutoff
                                        , pAdjustMethod = pAdjustMethod
                                        ,minGSSize = minGSSize, maxGSSize = maxGSSize
                                        , qvalueCutoff = qvalueCutoff
                                       )
  
  print('start GO....')
 
  print('Succ KEGG,Start GO_BP')
  bp_enrich=clusterProfiler::enricher(eg$ENTREZID, pvalueCutoff = pvalueCutoff
                                        , pAdjustMethod = pAdjustMethod
                                        ,minGSSize = minGSSize, maxGSSize = maxGSSize
                                        , qvalueCutoff = qvalueCutoff
                                        )
  print('Succ GP_BP,Start GO_CC')
  cc_enrich=clusterProfiler::enricher(eg$ENTREZID, pvalueCutoff = pvalueCutoff
                                      , pAdjustMethod = pAdjustMethod
                                      ,minGSSize = minGSSize, maxGSSize = maxGSSize
                                      , qvalueCutoff = qvalueCutoff
                                      )
  print('Succ GO_CC,Start GO_MF')
  mf_enrich=clusterProfiler::enricher(eg$ENTREZID, pvalueCutoff = pvalueCutoff
                                      , pAdjustMethod = pAdjustMethod
                                      ,minGSSize = minGSSize, maxGSSize = maxGSSize
                                      , qvalueCutoff = qvalueCutoff
                                      )
  if(nrow(kegg_enrich)>0){
    kegg_enrich=setReadable(kegg_enrich,OrgDb = 'org.Hs.eg.db',keyType = 'ENTREZID')
  }
  if(nrow(bp_enrich)>0){
    bp_enrich=setReadable(bp_enrich,OrgDb = 'org.Hs.eg.db',keyType = 'ENTREZID')
  }
  if(nrow(cc_enrich)>0){
    cc_enrich=setReadable(cc_enrich,OrgDb = 'org.Hs.eg.db',keyType = 'ENTREZID')
  }
  if(nrow(mf_enrich)>0){
    mf_enrich=setReadable(mf_enrich,OrgDb = 'org.Hs.eg.db',keyType = 'ENTREZID')
  }

  enrich_tab=rbind(cbind(summary(kegg_enrich),DB=rep('pathway_KEGG',nrow(kegg_enrich)))
                   ,cbind(summary(bp_enrich),DB=rep('geneontology_Biological_Process',nrow(bp_enrich)))
                   ,cbind(summary(cc_enrich),DB=rep('geneontology_Cellular_Component',nrow(cc_enrich)))
                   ,cbind(summary(mf_enrich),DB=rep('geneontology_Molecular_Function',nrow(mf_enrich)))
  )
  enrich_tab=as.data.frame(enrich_tab)
  colnames(enrich_tab)[c(2,5,6,9)]=c('description','pValue','FDR','size')
  enrich_tab$enrichmentRatio=unlist(lapply(strsplit(enrich_tab[,3],'/'), function(x){
    x1=as.numeric(x)
    return(x1[1]/x1[2])
  }))
  return(list(KEGG=kegg_enrich,GO_BP=bp_enrich,GO_CC=cc_enrich,GO_MF=mf_enrich
              ,Enrich_tab=enrich_tab,PathwayClass=unique(kegg.idmap[,c(3,5,6)])))
}

###单因素
coxFun <- function(dat){

  library(survival)
  colnames(dat)=c('time','status','gene')
  fmla=as.formula("Surv(time,status)~gene")
  cox=coxph(fmla,data=dat)
  p=summary(cox)[[7]][5]
  result=c(p,summary(cox)[[8]][1],summary(cox)[[8]][3],summary(cox)[[8]][4])
  return(result)
}
####差异分析与火山图
limma_DEG=function(exp,group,ulab,dlab){
  library(limma)
  ind1=which(group==ulab)
  ind2=which(group==dlab)
  
  sml <- c(rep('G1',length(ind1)),rep('G0',length(ind2)))    # set group names
  eset=exp[,c(ind1,ind2)]
  fl <- as.factor(sml)
  
  design <- model.matrix(~fl+0)
  colnames(design) <- levels(fl)
  cont.matrix<-makeContrasts(contrasts='G1-G0',levels=design)
  #print(head(eset))
  fit<-lmFit (eset,design)
  fit2 <- contrasts.fit(fit, cont.matrix)
  fit2 <- eBayes(fit2)
  #print(sml)
  tT <- topTable(fit2, adjust="fdr", sort.by="B", number=nrow(eset))
  regulated=ifelse(tT$logFC>0,'Up','Down')
  lfcs=c(log2(1.2),log2(1.3),log2(1.5),1)
  all.deg.cnt=cbind()
  for(lfc in lfcs){
    deg1=regulated[which(abs(tT$logFC)>lfc&tT$P.Value<0.05)]
    deg2=regulated[which(abs(tT$logFC)>lfc&tT$P.Value<0.01)]
    deg3=regulated[which(abs(tT$logFC)>lfc&tT$adj.P.Val<0.05)]
    deg4=regulated[which(abs(tT$logFC)>lfc&tT$adj.P.Val<0.01)]
    all.deg.cnt=cbind(all.deg.cnt,c(paste0(sum(deg1=='Up'),'|',sum(deg1=='Down'))
      ,paste0(sum(deg2=='Up'),'|',sum(deg2=='Down'))
      ,paste0(sum(deg3=='Up'),'|',sum(deg3=='Down'))
      ,paste0(sum(deg4=='Up'),'|',sum(deg4=='Down'))))
  }
  row.names(all.deg.cnt)=c('p<0.05','p<0.01','FDR<0.05','FDR<0.01')
  colnames(all.deg.cnt)=paste0(c('1.2','1.3','1.5','2'),'-fold')
  return(list(Exp=eset,Group=group[c(ind1,ind2)],DEG=tT,Summary=all.deg.cnt))
}

my_getGeneFC=function(gene.exp,group,ulab=ulab,dlab=dlab){
  degs_C1_C3=limma_DEG(gene.exp, 
                          group,
                          ulab=ulab,
                          dlab=dlab)
  
  ## 未过滤任何基因
  degs_C1_C3_sig<-degs_C1_C3$DEG[which(degs_C1_C3$DEG$adj.P.Val <= 1),]
  library(clusterProfiler)
  library(org.Hs.eg.db)
  library(stringr)
  degs_C1_C3_sig_gene<-rownames(degs_C1_C3_sig)
  
  degs_gene_entz=bitr(degs_C1_C3_sig_gene,fromType="SYMBOL",toType="ENTREZID",OrgDb="org.Hs.eg.db")
  degs_gene_entz <- dplyr::distinct(degs_gene_entz,SYMBOL,.keep_all=TRUE)
  
  gene_df <- data.frame(logFC=degs_C1_C3_sig$logFC,
                        SYMBOL = rownames(degs_C1_C3_sig))
  gene_df <- merge(gene_df,degs_gene_entz,by="SYMBOL")
  head(gene_df)
  
  geneList<-gene_df$logFC
  names(geneList)=gene_df$ENTREZID 
  head(geneList)
  
  geneList=sort(geneList,decreasing = T)
  head(geneList) ## 降序排列
  return(geneList)
}
my_volcano=function(dat,p_cutoff=0.05,fc_cutoff=1,col=c("red","blue","black"),
                    ylab='-log10 (adj.PVal)',xlab='log2 (FoldChange)',leg.pos='right'){
  degs_dat=dat$DEG
  degs_dat$type=factor(ifelse(degs_dat$adj.P.Val<p_cutoff & abs(degs_dat$logFC) > fc_cutoff, 
                              ifelse(degs_dat$logFC> fc_cutoff ,'Up','Down'),'No Signif'),levels=c('Up','Down','No Signif'))
  p=ggplot(degs_dat,aes(x=logFC,y=-log10(adj.P.Val),color=type))+
    geom_point()+
    scale_color_manual(values=col)+#确定点的颜色
    # geom_text_repel(
    #   data = tcga.diff$DEG[tcga.diff$DEG$adj.P.Val<p_fit & abs(tcga.diff$DEG$logFC)>fc_fit,],
    #   #aes(label = Gene),
    #   size = 3,
    #   segment.color = "black", show.legend = FALSE )+#添加关注的点的基因名
    theme_bw()+#修改图片背景
    theme(
      legend.title = element_blank(),#不显示图例标题
      legend.position = leg.pos,
    )+
    ylab(ylab)+#修改y轴名称
    xlab(xlab)+#修改x轴名称
    geom_vline(xintercept=c(-fc_cutoff,fc_cutoff),lty=3,col="black",lwd=0.5) +#添加横线|FoldChange|>2
    geom_hline(yintercept = -log10(p_cutoff),lty=3,col="black",lwd=0.5)#添加竖线padj<0.05
  return(p)
}

###森林图
my_forestplot=function(dat,show_95CI=T,zero = 1,boxsize = 0.4,lineheight =5,colgap =2,lwd.zero=2,lwd.ci=2
                          ,box_col='#458B00',summary_col="#8B008B",lines_col='black',zero_col='#7AC5CD'
                          ,xlab='HR',lwd.xaxis=2,lty.ci = "solid",graph.pos = 2,xlim=NULL,xlog=F){
  nc=ncol(dat)
  nr=nrow(dat)
  library(forestplot)
  col=fpColors(box=box_col,summary=summary_col,lines = lines_col,zero = zero_col)
  
  if(nc>3){
    hr=as.numeric(dat[,nc-2])
    lower=as.numeric(dat[,nc-1])
    upper=as.numeric(dat[,nc])
    
    if(is.null(xlim)){
      xlim=c(min(lower,na.rm = T),max(upper,na.rm = T))
    }
    if(is.infinite(max(xlim))){
      xlim=c(xlim[1],5)
    }
    if(is.infinite(min(xlim))){
      xlim=c(0,xlim[2])
    }
    
    if(min(xlim)<=0){
      xlog=F
    }
    smary=rep(F,length(hr))
    nind=which(is.na(lower)|is.na(upper)|is.na(hr))
    smary[nind]=T
    labeltext=as.matrix(dat[,1:(nc-3)])
    if(show_95CI){
      adt=paste0(round(hr,2),'(',round(lower,2),',',round(upper,2),')')
      adt[nind]=''
      labeltext=cbind(labeltext,adt)
      colnames(labeltext)=c(colnames(labeltext)[1:(ncol(labeltext)-1)],'Hazard Ratio(95% CI)')
    }
    if(graph.pos>ncol(labeltext)+1){
      labeltext=ncol(labeltext)+1
    }else if(graph.pos<2){
      graph.pos=2
    }
    hz_list=list('2'=gpar(lty=1,col=summary_col),
                 '3'=gpar(lty=1,col=summary_col)
    )
    names(hz_list)=c(2,nrow(labeltext)+2)
    p=forestplot(labeltext = rbind(colnames(labeltext),labeltext),
              hrzl_lines = hz_list,
               mean = c(NA,hr),
               lower =c(NA,lower),
               upper = c(NA,upper),
               is.summary=c(T,smary),
               zero = zero,
               boxsize = boxsize, 
               lineheight = unit(lineheight,'mm'),
               colgap = unit(colgap,'mm'),
               lwd.zero = lwd.zero,
               lwd.ci = lwd.ci,
               col=col,
               xlab=xlab,
               lwd.xaxis=lwd.xaxis,
               lty.ci = lty.ci,
               clip = xlim,
               xlog=xlog,
               graph.pos = graph.pos)
    return(p)
  }
}




####wgcna
wgcna_get_power=function(exp,height=0,net_type='unsigned',blockSize = 7000){
  library(WGCNA)
  logs=c()
  #print('=====')
  filter.exp=exp
  sampleTree = hclust(dist(filter.exp), method = "average")
  #plot(sampleTree, main = "Sample clustering to detect outliers", sub="", xlab="")
  #dev.off()
  #height=140000
  #print(height)
  #print(min(sampleTree$height))
  if(height>min(sampleTree$height)){
    cte=cutree(tree = sampleTree,h = height)
    #plot(sampleTree)
    #abline(h=height)
    s.inds=match(names(which(cte==names(which.max(table(cte))))),row.names(filter.exp))
    #sum(sampleTree$height<height)
    logs=c(logs,paste0('remove samples:',(nrow(filter.exp)-length(s.inds)),' row count')) 
    filter.exp=filter.exp[s.inds,]
    #print('==0')
  }
  #print('===1')
  powers = c(c(1:10), seq(from = 12, to=30, by=2))
  #print('===2')
  #print(head(filter.exp))
  sft = pickSoftThreshold(filter.exp, powerVector=powers, 
                          networkType=net_type, verbose=5,blockSize = blockSize)
  #print('===3')
  cutPower=sft$powerEstimate
  if(is.na(cutPower)){
    cutPower=0
  }
  print(paste0('power succed:',cutPower,',starting plot'))
  logs=c(logs,paste0('power succed:',cutPower,',starting plot')) 
  
  #library(customLayout)
  #lay1 <- lay_new(
  #  matrix(1:1, nc = 1),
  #  widths = c(5),
  #  heights = c(4))
  #lay2 <- lay_new(
  #  matrix(1:2, nc = 2),
  #  widths = c(2.5,2.5),
  #  heights = c(4))
  
  #cl = lay_bind_row(lay1, lay2,heights = c(0.8,1))
  #lay_set(cl)
  
  layout(matrix(c(1,1,2,3),2,2,byrow=T),widths=c(1,1),heights=c(0.8,1))
  
  mai=par('mai')
  
  mai1=mai
  mai1[1]=0
  par(mai=mai1)
  plot(sampleTree, main = "Sample clustering to detect outliers", sub="", xlab="")
  if(height>min(sampleTree$height)){
    abline(h=height,col='red')
  }
  par(mai=mai)
  
  #lay_show(cl)
  #par(mfrow = c(1,2))
  
  cex1 = rep(0.9,length(sft$fitIndices[,1]))
  col1=rep('red',length(sft$fitIndices[,1]))
  if(cutPower>0){
    cex1[which(sft$fitIndices[,1]==cutPower)]=1.5
    col1[which(sft$fitIndices[,1]==cutPower)]='blue'
  }
  plot(sft$fitIndices[,1], -sign(sft$fitIndices[,3])*sft$fitIndices[,2],
       xlab="Soft Threshold (power)",
       ylab="Scale Free Topology Model Fit,signed R^2",type="n",
       main = paste("Scale independence"))
  text(sft$fitIndices[,1], -sign(sft$fitIndices[,3])*sft$fitIndices[,2],
       labels=powers,cex=cex1,col=col1)
  abline(h=0.85,col="red")
  
  plot(sft$fitIndices[,1], sft$fitIndices[,5],
       xlab="Soft Threshold (power)",ylab="Mean Connectivity", type="n",
       main = paste("Mean connectivity"))
  text(sft$fitIndices[,1], sft$fitIndices[,5], labels=powers, 
       cex=cex1, col=col1)
  arg=paste0('height=',height,',net_type=',net_type,',blockSize = ',blockSize)
  return(list(cutPower=cutPower,log=logs,Exp=filter.exp,arg=arg))  
}

WGCNA_getModule=function(exp,power,blockSize=7000,minModuleSize=30,deepSplit=2,mergeCutHeight = 0.25,net_type='unsigned'){
  #exp=filter.exp
  #power=5
  library(WGCNA)
  print('adjacency staring')
  adjacency = adjacency(exp, power = power,type = net_type)
  print('adjacency success')
  TOM = TOMsimilarity(adjacency)
  print('TOM success')
  dissTOM = 1-TOM
  plotTOM = dissTOM^7
  # Set diagonal to NA for a nicer plot
  diag(plotTOM) = NA
  # Call the plot function
  geneTree = hclust(as.dist(dissTOM), method = "average")
  
  # We like large modules, so we set the minimum module size relatively high:
  #minModuleSize = 30
  # Module identification using dynamic tree cut:
  dynamicMods = cutreeDynamic(dendro = geneTree, distM = dissTOM
                              ,deepSplit = deepSplit, pamRespectsDendro = FALSE,
                              minClusterSize = minModuleSize)
  print('dynamicMods success')
  # Convert numeric lables into colors
  dynamicColors = labels2colors(dynamicMods)
  #table(dynamicColors)
  dynamicColors = labels2colors(dynamicMods)
  
  MEList = moduleEigengenes(exp, colors = dynamicColors)
  MEs = MEList$eigengenes
  # Calculate dissimilarity of module eigengenes
  MEDiss = 1-cor(MEs)
  # Cluster module eigengenes
  METree = hclust(as.dist(MEDiss), method = "average")
  #MEDissThres = 0.25
  # Call an automatic merging function
  merge = mergeCloseModules(exp, dynamicColors, cutHeight = mergeCutHeight, verbose = 3)
  # The merged module colors
  mergedColors = merge$colors
  table(mergedColors)
  
  MEs=merge$newMEs
  Modules=cbind(dynamicColors,mergedColors)
  row.names(Modules)=colnames(exp)
  
  #moduleLabels = net$colors
  #moduleColors = labels2colors(moduleLabels)
  # Plot the dendrogram and the module colors underneath
  #plotDendroAndColors(geneTree, Modules,
  #                    c("Dynamic Module",'Merged Module'),
  #                    dendroLabels = FALSE, hang = 0.03,
  #                    addGuide = TRUE, guideHang = 0.05)
  arg=paste0('power=',power,',blockSize=',blockSize,',minModuleSize=',minModuleSize,',deepSplit=',deepSplit,',mergeCutHeight =',mergeCutHeight)

  return(list(MEs=MEs,Modules=Modules,Tree=geneTree,plotTOM=plotTOM,TOM=TOM,arg=arg))
  #TOMplot(plotTOM, net$dendrograms, moduleColors, 
  #        main = "Network heatmap plot, all genes")
  
}

barplot_point_tmp=function(labels,values,point_cols='red',point_sizes=1
                    ,xlab='value',legend.pos='auto',legend.title='Group',group=NA
                    ,color='npg',mx_color='red',min_color='blue'){
  library(ggplot2)
  if(length(point_cols)!=length(values)){
    if(legend.pos=='auto'){
      legend.pos=NULL
    }
    point_cols=rep(point_cols[1],length(values))
  }
  if(length(point_sizes)!=length(values)){
    point_sizes=rep(point_sizes[1],length(values))
  }
  data_m=data.frame(labels,values,point_cols,point_sizes,group)
  colnames(data_m)=c('ID','value','pcol','psize','bcol')
  data_m[,1]=factor(data_m[,1], levels = unique(data_m[,1]))
  
  g=ggplot(data_m, aes(value, ID)) + 
    geom_segment(aes(yend = ID,color = pcol), xend = 0) + 
    geom_point(size = data_m[,4], aes(color = pcol))
  if(class(point_cols)=='numeric'){
    #min_color='green'
    #mx_color='white'
    g=g+scale_color_gradient(low = min_color, high = mx_color)
  }else{
    g=g+scale_color_manual(breaks = point_cols,values=point_cols)
  }
  g=g+ylab('')+xlab(xlab)
  g=g+guides(colour=guide_legend(title=legend.title))
  if(!is.na(group)){
    g=g+facet_wrap(~bcol,nrow = 1)
  }
  return(g)
  
}
barplot_point=function(labels,values,point_cols='red',point_sizes=1
                          ,xlab='value',legend.pos='auto',legend.title='Group',group=NA
                          ,color='npg',mx_color='red',min_color='blue'){
  tryCatch({
    pcl=col2rgb(point_cols)
    return(barplot_point_tmp(labels,values,point_cols,point_sizes
                         ,xlab,legend.pos,legend.title,group
                         ,color=NULL,mx_color = mx_color,min_color = min_color))
  }, error = function(e){
    return(barplot_point_tmp(labels,values,point_cols,point_sizes
                                ,xlab,legend.pos,legend.title,group
                                ,color,mx_color,min_color))
  })
}

####组合图片
merge_plot=function(...,ncol = NULL, nrow = NULL,
                       labels = NULL, label.x = 0, label.y = 1, hjust = -0.5,
                       vjust = 1.5, font.label = list(size = 14, color = "black", face ="bold"
                                                      , family = NULL), align = c("none", "h", "v", "hv")
                       ,widths = 1, heights = 1, legend = NULL, common.legend = FALSE){
  ml=list(...)
  if(length(ml)==1){
    if(is.list(ml[[1]])){
      ml=ml[[1]]
    }
  }
  gal=ggpubr::ggarrange(plotlist = ml, ncol = ncol, nrow = nrow
                        ,labels = labels,label.x = label.x, label.y = label.y
                        , hjust = hjust,
                        vjust = vjust, font.label = font.label, align = align
                        ,widths = widths, heights = heights, legend = legend
                        , common.legend = common.legend
  )
  return(gal)
}