library(GEOquery)
GSE70769 <- getGEO(filename = "data/GSE70769_series_matrix.txt.gz", GSEMatrix =TRUE, getGPL=FALSE)
GSE70769.cli=pData(GSE70769)
head(GSE70769.cli)
GSE70769.cli=data.frame(Samples=GSE70769.cli$geo_accession,
                         BCR=GSE70769.cli$`biochemical relapse (bcr):ch1`,
                         BCR.time=GSE70769.cli$`time to bcr (months):ch1`,
                         follow.up=GSE70769.cli$`total follow up (months):ch1`,
                         ece=GSE70769.cli$`extra capsular extension (ece):ch1`,
                         psm=GSE70769.cli$`positive surgical margins (psm):ch1`)
head(GSE70769.cli)
GSE70769.cli$BCR
GSE70769.cli=GSE70769.cli %>% subset(BCR!='N/A') %>% subset(BCR.time>1 & BCR.time!='UNKNOWN') 
GSE70769.cli$BCR=ifelse(GSE70769.cli$BCR=='N',0,1)

GSE70769.cli$BCR.time1=GSE70769.cli$follow.up
GSE70769.cli$BCR.time1
GSE70769.cli=as.data.frame(GSE70769.cli)
dim(GSE70769.cli)



GSE70768 <- getGEO(filename = "feedback_20260205/data/GSE70768_series_matrix.txt.gz", GSEMatrix =TRUE, getGPL=FALSE)

GSE70768.cli=pData(GSE70768)
head(GSE70768.cli)
GSE70768.cli=data.frame(Samples=GSE70768.cli$geo_accession,
                         BCR=GSE70768.cli$`biochemical relapse (bcr):ch1`,
                         BCR.time=GSE70768.cli$`time to bcr (months):ch1`,
                         follow.up=GSE70768.cli$`total follow up (months):ch1`,
                         ece=GSE70768.cli$`extra-capsular extension (ece):ch1`,
                         psm=GSE70768.cli$`positive surgical margins (psm):ch1`)
head(GSE70768.cli)
GSE70768.cli$BCR
table(GSE70768.cli$ece,GSE70768.cli$psm)
GSE70768.cli=GSE70768.cli %>% subset(BCR!='N/A')

GSE70768.cli$BCR=ifelse(GSE70768.cli$BCR=='N',0,1)
GSE70768.cli$BCR.time1=GSE70768.cli$follow.up
GSE70768.cli$BCR.time1
GSE70768.cli=as.data.frame(GSE70768.cli)
GSE70768.cli=GSE70768.cli %>% 
  drop_na(BCR.time1) 
dim(GSE70769.cli)

GSE70768.mat=exprs(GSE70768)
GSE70768.mat[1:5,1:5]
GSE70768.exp=exp_probe2symbol_v2(datExpr = GSE70768.mat,GPL = 'GPL10558')

GSE70769.mat=exprs(GSE70769)
GSE70769.mat[1:5,1:5]
GSE70769.exp=exp_probe2symbol_v2(datExpr = GSE70769.mat,GPL = 'GPL10558')


merge.cli=rbind(GSE70768.cli,
                GSE70769.cli)
merge.cli$dataset=rep(c('GSE70768','GSE70769'),c(111,90))

com.genes=intersect(rownames(GSE70768.exp),
                    rownames(GSE70769.exp))

merge.before=cbind(GSE70768.exp[com.genes,GSE70768.cli$Samples],
                   GSE70769.exp[com.genes,GSE70769.cli$Samples])
dim(merge.before)
merge.before <- na.omit(merge.before)
dim(merge.before)
# 23391   201

##去批次###########
library(ggbiplot)
before.pca <- prcomp(t(merge.before), scale=T)
pca_before <- ggbiplot(before.pca, scale=1, groups = merge.cli$dataset,
                       ellipse = TRUE,ellipse.prob=0.5, circle = F,var.axes=F) +
  scale_color_manual(values = ggsci::pal_lancet('lanonc')(9)) + 
  # xlim(-5, 5) + ylim(-5,5) +
  theme_light() +
  theme(legend.direction = 'horizontal', legend.position = 'top') +
  xlab('PCA1') + ylab('PCA2')
pca_before

#去除批次效应
library(sva)

merge.after = ComBat(merge.before,batch =  merge.cli$dataset)
dim(merge.after)

after.pca <- prcomp(t(merge.after), scale=T)
pca_after <- ggbiplot(after.pca, scale=1, groups =  merge.cli$dataset,
                      ellipse = TRUE,ellipse.prob=0.5, circle = F,var.axes=F) +
  scale_color_manual(values = ggsci::pal_lancet('lanonc')(9)) + 
  # xlim(-5, 5) + ylim(-5,5) +
  theme_light() +
  theme(legend.direction = 'horizontal', legend.position = 'top') +
  xlab('PCA1') + ylab('PCA2')
pca_after


##生存曲线#########
merge.cli.df=data.frame(EPHB1=as.numeric(merge.after['EPHB1',merge.cli$Samples]),merge.cli)
head(merge.cli.df)
table(merge.cli.df$ece)
table(merge.cli.df$psm)
table(merge.cli.df$ece,merge.cli.df$psm)

merge.cli.df.filter = merge.cli.df %>% 
  subset(ece=='Y') %>%
  subset(psm=='Y') %>%
  mutate(group= ifelse(EPHB1 > median(EPHB1), 'High', 'Low'))
dim(merge.cli.df.filter)
#43
table(merge.cli.df.filter$group)
merge.cli.df.filter=as.data.frame(merge.cli.df.filter)
merge.cli.df.filter$BCR.time1=as.numeric(merge.cli.df.filter$BCR.time1)
p=ggsurvplot(fit=survfit( Surv(BCR.time1, BCR ) ~ group,
                        data = merge.cli.df.filter),
           data=merge.cli.df.filter,
           conf.int = F,pval = T,fun = "pct",risk.table =T, size = 0.7,
           surv.median.line = 'hv',
           linetype = c("solid", "dashed","strata")[1],
           palette = c('orange','grey'),
           #legend = c('top', 'bottom', 'left', 'right', 'none')[5],
           legend = c(0.8,0.95), # 指定图例位置
           legend.labs=c('High EPHB1','Low EPHB1'),
           legend.title = "")
p

